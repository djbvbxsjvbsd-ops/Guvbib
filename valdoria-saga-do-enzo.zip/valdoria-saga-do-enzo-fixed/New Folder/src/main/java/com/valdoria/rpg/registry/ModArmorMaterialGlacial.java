// [ModArmorMaterialGlacial.java]
package com.valdoria.rpg.registry;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;
import org.jetbrains.annotations.NotNull;
public enum ModArmorMaterialGlacial implements ArmorMaterial {
    GLACIAL("glacial", 30, new int[]{5, 10, 8, 5}, 15, SoundEvents.ARMOR_EQUIP_DIAMOND, 2.0F, 0.1F);
    private final String name;
    private final int durabilityMultiplier;
    private final int[] slotProtections;
    private final int enchantmentValue;
    private final SoundEvent sound;
    private final float toughness;
    private final float knockbackResistance;
    private static final int[] BASE_DURABILITY = {13, 15, 16, 11};
    ModArmorMaterialGlacial(String name, int dur, int[] prot, int ench, SoundEvent sound, float tough, float kb) {
        this.name = name;
        this.durabilityMultiplier = dur;
        this.slotProtections = prot;
        this.enchantmentValue = ench;
        this.sound = sound;
        this.toughness = tough;
        this.knockbackResistance = kb;
    }
    @Override public int getDurabilityForType(ArmorItem.Type t) { return BASE_DURABILITY[t.getSlot().getIndex()] * durabilityMultiplier; }
    @Override public int getDefenseForType(ArmorItem.Type t) { return slotProtections[t.getSlot().getIndex()]; }
    @Override public int getEnchantmentValue() { return enchantmentValue; }
    @Override public @NotNull SoundEvent getEquipSound() { return sound; }
    @Override public @NotNull Ingredient getRepairIngredient() { return Ingredient.of(ModItems.CRISTAL_GLACIAL.get()); }
    @Override public @NotNull String getName() { return name; }
    @Override public float getToughness() { return toughness; }
    @Override public float getKnockbackResistance() { return knockbackResistance; }
}
