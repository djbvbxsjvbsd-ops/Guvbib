package com.valdoria.rpg.client.screen;

import com.valdoria.rpg.client.ClientData;
import net.minecraft.client.gui.GuiGraphics;
import java.util.Random;

public class UITheme {

    public static int getBgColor() {
        if (ClientData.inNiveria) return 0xCC001A1A;
        return switch (ClientData.faction) {
            case 1  -> 0xCC00001E;
            case 2  -> 0xCC1E0000;
            default -> 0xCC0D0619;
        };
    }

    public static int getBorderColorBase() {
        if (ClientData.inNiveria) return 0xFF00E5FF;
        return switch (ClientData.faction) {
            case 1  -> 0xFFFFD700;
            case 2  -> 0xFFDC143C;
            default -> 0xFFDDA0DD;
        };
    }

    public static int getAnimatedBorderColor(long time) {
        double sin   = Math.sin(time / 500.0);
        int    alpha = (int)(207 + sin * 48);
        alpha = Math.max(0, Math.min(255, alpha));
        int base = getBorderColorBase();
        int r = (base >> 16) & 0xFF;
        int g = (base >>  8) & 0xFF;
        int b = (base      ) & 0xFF;
        return (alpha << 24) | (r << 16) | (g << 8) | b;
    }

    public static void fillRect(GuiGraphics g, int x, int y, int w, int h, int argb) {
        g.fill(x, y, x + w, y + h, argb);
    }

    public static void renderBorder(GuiGraphics g, int x, int y, int w, int h, long time) {
        int col = getAnimatedBorderColor(time);
        g.fill(x,         y,         x + w,     y + 1,     col);
        g.fill(x,         y + h - 1, x + w,     y + h,     col);
        g.fill(x,         y,         x + 1,     y + h,     col);
        g.fill(x + w - 1, y,         x + w,     y + h,     col);
    }

    public static void renderPanel(GuiGraphics g, int x, int y, int w, int h, long time) {
        fillRect(g, x, y, w, h, getBgColor());
        renderBorder(g, x, y, w, h, time);
    }

    // ── Snow ──────────────────────────────────────────────────────────────
    private static final int   FLAKES    = 40;
    private static final int[] SNOW_X    = new int[FLAKES];
    private static final int[] SNOW_Y    = new int[FLAKES];
    private static final int[] SNOW_SPD  = new int[FLAKES];
    private static final int[] SNOW_SZ   = new int[FLAKES];
    private static       int   sW = 0, sH = 0;
    private static       boolean sInit = false;

    private static void initSnow(int w, int h) {
        Random rng = new Random(0xC0LD);
        for (int i = 0; i < FLAKES; i++) {
            SNOW_X[i]   = rng.nextInt(Math.max(1, w));
            SNOW_Y[i]   = rng.nextInt(Math.max(1, h));
            SNOW_SPD[i] = 1 + rng.nextInt(2);
            SNOW_SZ[i]  = 1 + rng.nextInt(2);
        }
        sW = w; sH = h; sInit = true;
    }

    public static void renderSnow(GuiGraphics g, int x, int y, int w, int h) {
        if (!sInit || sW != w || sH != h) initSnow(w, h);
        int col = 0xBBDDEEFF;
        for (int i = 0; i < FLAKES; i++) {
            int px = x + SNOW_X[i];
            int py = y + SNOW_Y[i];
            int sz = SNOW_SZ[i];
            g.fill(px, py, px + sz, py + sz, col);
            SNOW_Y[i] += SNOW_SPD[i];
            if (SNOW_Y[i] > h) {
                SNOW_Y[i] = -sz;
                SNOW_X[i] = (SNOW_X[i] + 7 + i) % Math.max(1, w);
            }
        }
    }

    // ── Colour tokens ─────────────────────────────────────────────────────
    public static int hpColor()    { return 0xFFFF4444; }
    public static int manaColor()  { return 0xFF4488FF; }
    public static int xpColor()    { return 0xFF44FF88; }
    public static int foodColor()  { return 0xFFFF9900; }
    public static int questColor() { return 0xFFFFD700; }
    public static int tickColor()  { return 0xFF55FF55; }
    public static int crossColor() { return 0xFF888888; }
}
