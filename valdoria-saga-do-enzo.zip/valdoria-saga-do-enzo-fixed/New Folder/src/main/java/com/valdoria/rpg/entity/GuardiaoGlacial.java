// [GuardiaoGlacial.java]
package com.valdoria.rpg.entity;
import com.valdoria.rpg.data.PlayerData;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.IronGolem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
public class GuardiaoGlacial extends IronGolem {
    private final ServerBossEvent bossBar = new ServerBossEvent(
            Component.literal("Guardião Glacial"), BossEvent.BossBarColor.BLUE, BossEvent.BossBarOverlay.PROGRESS);
    public GuardiaoGlacial(EntityType<? extends GuardiaoGlacial> type, Level level) {
        super(type, level);
        this.setCustomName(Component.literal("Guardião Glacial"));
        this.setPersistenceRequired();
    }
    public static AttributeSupplier.Builder createAttributes() {
        return IronGolem.createAttributes()
                .add(Attributes.MAX_HEALTH, 150.0D)
                .add(Attributes.ATTACK_DAMAGE, 10.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.22D);
    }
    @Override
    public void startSeenByPlayer(ServerPlayer p) { super.startSeenByPlayer(p); bossBar.addPlayer(p); }
    @Override
    public void stopSeenByPlayer(ServerPlayer p) { super.stopSeenByPlayer(p); bossBar.removePlayer(p); }
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossBar.setProgress(getHealth() / getMaxHealth());
        if (tickCount % 40 == 0) {
            for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(5.0D))) {
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
            }
        }
    }
    @Override
    public void die(DamageSource src) {
        super.die(src);
        bossBar.removeAllPlayers();
    }
}
