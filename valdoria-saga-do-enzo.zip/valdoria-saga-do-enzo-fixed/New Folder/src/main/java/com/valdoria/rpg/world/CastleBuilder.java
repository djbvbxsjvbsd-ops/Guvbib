// [CastleBuilder.java]
package com.valdoria.rpg.world;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
public final class CastleBuilder {
    private CastleBuilder() {}
    public static void build(ServerLevel level, BlockPos origin, int stage) {
        if (stage >= 1) buildStage1(level, origin);
        if (stage >= 2) buildStage2(level, origin);
        if (stage >= 3) buildStage3(level, origin);
        if (stage >= 4) buildStage4(level, origin);
        if (stage >= 5) buildStage5(level, origin);
        if (stage >= 6) buildStage6(level, origin);
        if (stage >= 7) buildStage7(level, origin);
        if (stage >= 8) buildStage8(level, origin);
        if (stage >= 9) buildStage9(level, origin);
    }
    private static void place(ServerLevel level, int x, int y, int z, BlockState state) {
        level.setBlockAndUpdate(new BlockPos(x, y, z), state);
    }
    private static int bx(BlockPos o) { return o.getX(); }
    private static int by(BlockPos o) { return o.getY(); }
    private static int bz(BlockPos o) { return o.getZ(); }
    private static void buildStage1(ServerLevel level, BlockPos o) {
        int ox = bx(o), oy = by(o), oz = bz(o);
        for (int x = ox - 7; x <= ox + 7; x++) {
            for (int z = oz - 7; z <= oz + 7; z++) {
                place(level, x, oy - 1, z, Blocks.STONE_BRICKS.defaultBlockState());
            }
        }
        place(level, ox - 7, oy, oz - 7, Blocks.TORCH.defaultBlockState());
        place(level, ox + 7, oy, oz - 7, Blocks.TORCH.defaultBlockState());
        place(level, ox - 7, oy, oz + 7, Blocks.TORCH.defaultBlockState());
        place(level, ox + 7, oy, oz + 7, Blocks.TORCH.defaultBlockState());
    }
    private static void buildStage2(ServerLevel level, BlockPos o) {
        int ox = bx(o), oy = by(o), oz = bz(o);
        for (int h = 0; h < 3; h++) {
            for (int x = ox - 7; x <= ox + 7; x++) {
                place(level, x, oy + h, oz - 7, Blocks.COBBLESTONE.defaultBlockState());
                place(level, x, oy + h, oz + 7, Blocks.COBBLESTONE.defaultBlockState());
            }
            for (int z = oz - 6; z <= oz + 6; z++) {
                place(level, ox - 7, oy + h, z, Blocks.COBBLESTONE.defaultBlockState());
                place(level, ox + 7, oy + h, z, Blocks.COBBLESTONE.defaultBlockState());
            }
        }
    }
    private static void buildStage3(ServerLevel level, BlockPos o) {
        int ox = bx(o), oy = by(o), oz = bz(o);
        for (int h = 0; h < 3; h++) {
            place(level, ox - 1, oy + h, oz - 7, Blocks.AIR.defaultBlockState());
            place(level, ox, oy + h, oz - 7, Blocks.AIR.defaultBlockState());
            place(level, ox + 1, oy + h, oz - 7, Blocks.AIR.defaultBlockState());
        }
        place(level, ox - 1, oy, oz - 7, Blocks.OAK_DOOR.defaultBlockState());
        place(level, ox, oy, oz - 7, Blocks.OAK_DOOR.defaultBlockState());
        place(level, ox - 2, oy, oz - 7, Blocks.TORCH.defaultBlockState());
        place(level, ox + 2, oy, oz - 7, Blocks.TORCH.defaultBlockState());
    }
    private static void buildStage4(ServerLevel level, BlockPos o) {
        int ox = bx(o), oy = by(o), oz = bz(o);
        int[][] corners = {{ox - 7, oz - 7}, {ox + 7, oz - 7}, {ox - 7, oz + 7}, {ox + 7, oz + 7}};
        for (int[] c : corners) {
            for (int h = 0; h < 5; h++) {
                for (int dx = -1; dx <= 1; dx++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        place(level, c[0] + dx, oy + h, c[1] + dz, Blocks.COBBLESTONE.defaultBlockState());
                    }
                }
            }
            for (int h = 0; h < 5; h++) {
                place(level, c[0], oy + h, c[1], Blocks.COBBLESTONE_STAIRS.defaultBlockState());
            }
        }
    }
    private static void buildStage5(ServerLevel level, BlockPos o) {
        int ox = bx(o), oy = by(o), oz = bz(o);
        for (int x = ox - 3; x <= ox + 3; x++) {
            for (int z = oz - 3; z <= oz + 3; z++) {
                place(level, x, oy - 1, z, Blocks.POLISHED_ANDESITE.defaultBlockState());
                if (x == ox - 3 || x == ox + 3 || z == oz - 3 || z == oz + 3) {
                    for (int h = 0; h < 3; h++) {
                        place(level, x, oy + h, z, Blocks.STONE_BRICKS.defaultBlockState());
                    }
                }
            }
        }
        place(level, ox, oy, oz + 3, Blocks.OAK_PLANKS.defaultBlockState());
        place(level, ox - 1, oy, oz + 3, Blocks.OAK_PLANKS.defaultBlockState());
        place(level, ox + 1, oy, oz + 3, Blocks.OAK_PLANKS.defaultBlockState());
        place(level, ox, oy + 1, oz + 3, Blocks.OAK_PLANKS.defaultBlockState());
        for (int x = ox - 2; x <= ox + 2; x++) {
            place(level, x, oy - 1, oz, Blocks.RED_CARPET.defaultBlockState());
        }
    }
    private static void buildStage6(ServerLevel level, BlockPos o) {
        int ox = bx(o), oy = by(o), oz = bz(o);
        for (int x = ox - 3; x <= ox + 3; x++) {
            for (int z = oz - 3; z <= oz + 3; z++) {
                place(level, x, oy + 3, z, Blocks.DARK_OAK_PLANKS.defaultBlockState());
            }
        }
        int[][] windows = {{ox - 3, oz - 1}, {ox - 3, oz}, {ox - 3, oz + 1}, {ox + 3, oz - 1}, {ox + 3, oz}, {ox + 3, oz + 1}, {ox - 1, oz - 3}, {ox + 1, oz - 3}};
        for (int[] w : windows) {
            place(level, w[0], oy + 1, w[1], Blocks.GLASS.defaultBlockState());
        }
    }
    private static void buildStage7(ServerLevel level, BlockPos o) {
        int ox = bx(o), oy = by(o), oz = bz(o);
        int[][] corners = {{ox - 7, oz - 7}, {ox + 7, oz - 7}, {ox - 7, oz + 7}, {ox + 7, oz + 7}};
        for (int[] c : corners) {
            for (int h = 0; h < 8; h++) {
                for (int dx = -1; dx <= 1; dx++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        place(level, c[0] + dx, oy + h, c[1] + dz, Blocks.STONE_BRICKS.defaultBlockState());
                    }
                }
            }
        }
        place(level, ox - 7, oy + 8, oz - 7, Blocks.RED_WOOL.defaultBlockState());
        place(level, ox + 7, oy + 8, oz - 7, Blocks.RED_WOOL.defaultBlockState());
        place(level, ox - 7, oy + 8, oz + 7, Blocks.RED_WOOL.defaultBlockState());
        place(level, ox + 7, oy + 8, oz + 7, Blocks.RED_WOOL.defaultBlockState());
    }
    private static void buildStage8(ServerLevel level, BlockPos o) {
        int ox = bx(o), oy = by(o), oz = bz(o);
        place(level, ox, oy + 9, oz, Blocks.BEACON.defaultBlockState());
        for (int x = ox - 8; x <= ox + 8; x++) {
            for (int z = oz - 8; z <= oz + 8; z++) {
                if (x == ox - 8 || x == ox + 8 || z == oz - 8 || z == oz + 8) {
                    for (int h = 0; h < 3; h++) {
                        place(level, x, oy + h, z, Blocks.STONE_BRICKS.defaultBlockState());
                    }
                }
            }
        }
        int[][] torchPos = {{ox - 4, oz - 7}, {ox + 4, oz - 7}, {ox - 4, oz + 7}, {ox + 4, oz + 7}, {ox - 7, oz - 4}, {ox - 7, oz + 4}, {ox + 7, oz - 4}, {ox + 7, oz + 4}, {ox, oz - 7}, {ox, oz + 7}, {ox - 7, oz}, {ox + 7, oz}, {ox - 5, oz - 5}, {ox + 5, oz - 5}, {ox - 5, oz + 5}, {ox + 5, oz + 5}};
        for (int[] t : torchPos) {
            place(level, t[0], oy + 3, t[1], Blocks.TORCH.defaultBlockState());
        }
    }
    private static void buildStage9(ServerLevel level, BlockPos o) {
        int ox = bx(o), oy = by(o), oz = bz(o);
        for (int x = ox - 20; x <= ox + 20; x++) {
            for (int z = oz - 20; z <= oz + 20; z++) {
                if (x == ox - 20 || x == ox + 20 || z == oz - 20 || z == oz + 20) {
                    for (int h = 0; h < 6; h++) {
                        place(level, x, oy + h, z, Blocks.STONE_BRICKS.defaultBlockState());
                    }
                    if ((x - ox - 20) % 2 == 0 || (z - oz - 20) % 2 == 0) {
                        place(level, x, oy + 6, z, Blocks.STONE_BRICKS.defaultBlockState());
                    }
                }
            }
        }
        int[][] towerPos = {{ox - 20, oz - 20}, {ox + 20, oz - 20}, {ox - 20, oz + 20}, {ox + 20, oz + 20}, {ox, oz - 20}, {ox, oz + 20}, {ox - 20, oz}, {ox + 20, oz}};
        for (int[] t : towerPos) {
            buildMegaTower(level, t[0], oy, t[1]);
        }
        for (int x = ox - 7; x <= ox + 7; x++) {
            for (int z = oz - 7; z <= oz + 7; z++) {
                place(level, x, oy - 1, z, Blocks.QUARTZ_BLOCK.defaultBlockState());
                if (x == ox - 7 || x == ox + 7 || z == oz - 7 || z == oz + 7) {
                    for (int h = 0; h < 7; h++) {
                        place(level, x, oy + h, z, Blocks.STONE_BRICKS.defaultBlockState());
                    }
                    for (int h = 0; h < 7; h++) {
                        place(level, x, oy + h, z, Blocks.STONE_BRICKS.defaultBlockState());
                    }
                }
            }
        }
        for (int h = 0; h < 7; h++) {
            place(level, ox, oy + h, oz + 7, Blocks.STONE_BRICKS.defaultBlockState());
        }
        for (int x = ox - 6; x <= ox + 6; x++) {
            for (int z = oz - 6; z <= oz + 6; z++) {
                place(level, x, oy, z, Blocks.DARK_OAK_PLANKS.defaultBlockState());
            }
        }
        for (int x = ox - 2; x <= ox + 2; x++) {
            place(level, x, oy, oz + 6, Blocks.RED_CARPET.defaultBlockState());
        }
        for (int x = ox - 1; x <= ox + 1; x++) {
            for (int z = oz + 2; z <= oz + 5; z++) {
                place(level, x, oy, z, Blocks.GOLD_BLOCK.defaultBlockState());
            }
        }
        place(level, ox, oy + 1, oz + 4, Blocks.GOLD_BLOCK.defaultBlockState());
        for (int h = 7; h < 12; h++) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    place(level, ox + dx, oy + h, oz + dz, Blocks.DARK_OAK_PLANKS.defaultBlockState());
                }
            }
        }
        place(level, ox, oy + 12, oz, Blocks.BEACON.defaultBlockState());
        for (int x = ox - 20; x <= ox + 20; x++) {
            for (int z = oz - 20; z <= oz + 20; z++) {
                int dx = x - ox, dz = z - oz;
                if (Math.abs(dx) > 20 || Math.abs(dz) > 20) continue;
                if (Math.abs(dx) == 21 || Math.abs(dz) == 21) {
                    for (int h = -2; h <= -1; h++) {
                        place(level, x, oy + h, z, Blocks.WATER.defaultBlockState());
                    }
                }
            }
        }
        buildMoat(level, ox, oy, oz);
        int[][] torches32 = new int[32][2];
        int ti = 0;
        for (int offset = -18; offset <= 18; offset += 6) {
            if (ti < 32) { torches32[ti][0] = ox + offset; torches32[ti][1] = oz - 20; ti++; }
            if (ti < 32) { torches32[ti][0] = ox + offset; torches32[ti][1] = oz + 20; ti++; }
            if (ti < 32) { torches32[ti][0] = ox - 20; torches32[ti][1] = oz + offset; ti++; }
            if (ti < 32) { torches32[ti][0] = ox + 20; torches32[ti][1] = oz + offset; ti++; }
        }
        for (int i = 0; i < Math.min(ti, 32); i++) {
            place(level, torches32[i][0], oy + 6, torches32[i][1], Blocks.TORCH.defaultBlockState());
        }
        int[][] lanterns = {{ox - 10, oz - 10}, {ox + 10, oz - 10}, {ox - 10, oz + 10}, {ox + 10, oz + 10}, {ox - 15, oz - 15}, {ox + 15, oz - 15}, {ox - 15, oz + 15}, {ox + 15, oz + 15}, {ox - 5, oz - 10}, {ox + 5, oz - 10}, {ox - 10, oz - 5}, {ox + 10, oz - 5}, {ox - 5, oz + 10}, {ox + 5, oz + 10}, {ox - 10, oz + 5}, {ox + 10, oz + 5}};
        for (int[] l : lanterns) {
            place(level, l[0], oy + 1, l[1], Blocks.LANTERN.defaultBlockState());
        }
        int[][] banners = {{ox - 19, oz - 19}, {ox + 19, oz - 19}, {ox - 19, oz + 19}, {ox + 19, oz + 19}};
        for (int[] b : banners) {
            place(level, b[0], oy + 7, b[1], Blocks.RED_WOOL.defaultBlockState());
            place(level, b[0], oy + 8, b[1], Blocks.YELLOW_WOOL.defaultBlockState());
        }
    }
    private static void buildMegaTower(ServerLevel level, int tx, int oy, int tz) {
        for (int h = 0; h < 15; h++) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    if (Math.abs(dx) == 2 || Math.abs(dz) == 2) {
                        level.setBlockAndUpdate(new BlockPos(tx + dx, oy + h, tz + dz), Blocks.STONE_BRICKS.defaultBlockState());
                    }
                }
            }
        }
        for (int h = 12; h <= 15; h++) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    level.setBlockAndUpdate(new BlockPos(tx + dx, oy + h, tz + dz), Blocks.BRICK.defaultBlockState());
                }
            }
        }
        for (int h = 0; h < 15; h++) {
            level.setBlockAndUpdate(new BlockPos(tx, oy + h, tz), Blocks.COBBLESTONE_STAIRS.defaultBlockState());
        }
    }
    private static void buildMoat(ServerLevel level, int ox, int oy, int oz) {
        for (int x = ox - 22; x <= ox + 22; x++) {
            for (int z = oz - 22; z <= oz + 22; z++) {
                boolean outer = (Math.abs(x - ox) >= 21 || Math.abs(z - oz) >= 21);
                boolean inner = (Math.abs(x - ox) <= 20 && Math.abs(z - oz) <= 20);
                if (outer && !inner) {
                    for (int h = -2; h <= -1; h++) {
                        level.setBlockAndUpdate(new BlockPos(x, oy + h, z), Blocks.WATER.defaultBlockState());
                    }
                }
            }
        }
    }
}
