package com.valdoria.rpg.client.screen;

import com.valdoria.rpg.network.FactionChoicePacket;
import com.valdoria.rpg.network.ModNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public class FactionScreen extends Screen {
    private static final int CARD_W = 130, CARD_H = 160;

    public FactionScreen() {
        super(Component.literal("Escolha sua Facção"));
    }

    private int leftX() { return width / 2 - CARD_W - 10; }
    private int rightX() { return width / 2 + 10; }
    private int topY() { return height / 2 - CARD_H / 2; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.drawCenteredString(font, "§6§lA ESCOLHA DE ENZO", width / 2, topY() - 26, 0xFFFFFF);
        g.drawCenteredString(font, "Pressione 1 (Anjo) ou 2 (Demônio)", width / 2, topY() + CARD_H + 10, 0xAAAAAA);
        card(g, leftX(), topY(), true, hover(mx, my, leftX()));
        card(g, rightX(), topY(), false, hover(mx, my, rightX()));
        super.render(g, mx, my, pt);
    }

    private boolean hover(int mx, int my, int x) {
        return mx >= x && mx <= x + CARD_W && my >= topY() && my <= topY() + CARD_H;
    }

    private void card(GuiGraphics g, int x, int y, boolean angel, boolean hover) {
        int top = angel ? (hover ? 0xFF9FD8FF : 0xFF5A93C8) : (hover ? 0xFF8A1F1F : 0xFF4A0E12);
        int bottom = angel ? 0xFF1B3A5E : 0xFF14040A;
        g.fillGradient(x, y, x + CARD_W, y + CARD_H, top, bottom);
        g.renderOutline(x, y, CARD_W, CARD_H, angel ? 0xFFFFE066 : 0xFFFF5522);
        int cx = x + CARD_W / 2, cy = y + 62;
        if (angel) drawAngel(g, cx, cy); else drawDemon(g, cx, cy);
        g.drawCenteredString(font, angel ? "§e§l[1] ANJO" : "§c§l[2] DEMÔNIO", cx, y + 108, 0xFFFFFF);
        g.drawCenteredString(font, angel ? "Luz" : "Trevas", cx, y + 120, 0xDDDDDD);
        g.drawCenteredString(font, angel ? "Mana regenera mais" : "+15% de dano", cx, y + 136, 0xFFFFFF);
    }

    private void drawAngel(GuiGraphics g, int cx, int cy) {
        g.fill(cx - 36, cy - 4, cx - 12, cy + 20, 0xFFDDEEFF);   // asas
        g.fill(cx + 12, cy - 4, cx + 36, cy + 20, 0xFFDDEEFF);
        g.fill(cx - 12, cy - 2, cx + 12, cy + 30, 0xFFFFFFFF);   // corpo
        g.fill(cx - 9, cy - 22, cx + 9, cy - 4, 0xFFFFE0BD);     // cabeça
        g.fill(cx - 5, cy - 16, cx - 2, cy - 13, 0xFF222222);    // olhos
        g.fill(cx + 2, cy - 16, cx + 5, cy - 13, 0xFF222222);
        g.fill(cx - 12, cy - 32, cx + 12, cy - 29, 0xFFFFE066);  // auréola
        g.fill(cx - 12, cy - 26, cx + 12, cy - 24, 0xFFFFE066);
        g.fill(cx - 12, cy - 32, cx - 10, cy - 24, 0xFFFFE066);
        g.fill(cx + 10, cy - 32, cx + 12, cy - 24, 0xFFFFE066);
    }

    private void drawDemon(GuiGraphics g, int cx, int cy) {
        g.fill(cx - 38, cy - 6, cx - 12, cy + 18, 0xFF550022);   // asas
        g.fill(cx + 12, cy - 6, cx + 38, cy + 18, 0xFF550022);
        g.fill(cx - 12, cy - 2, cx + 12, cy + 30, 0xFF330011);   // corpo
        g.fill(cx - 9, cy - 22, cx + 9, cy - 4, 0xFFAA1111);     // cabeça
        g.fill(cx - 13, cy - 32, cx - 8, cy - 18, 0xFF220000);   // chifres
        g.fill(cx + 8, cy - 32, cx + 13, cy - 18, 0xFF220000);
        g.fill(cx - 6, cy - 16, cx - 2, cy - 12, 0xFFFFE000);   // olhos
        g.fill(cx + 2, cy - 16, cx + 6, cy - 12, 0xFFFFE000);
        g.fill(cx - 5, cy - 9, cx + 5, cy - 7, 0xFF000000);      // boca
        g.fill(cx + 12, cy + 24, cx + 22, cy + 27, 0xFFAA1111);  // cauda
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (hover((int) mx, (int) my, leftX())) { choose(1); return true; }
        if (hover((int) mx, (int) my, rightX())) { choose(2); return true; }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_1 || key == GLFW.GLFW_KEY_KP_1) { choose(1); return true; }
        if (key == GLFW.GLFW_KEY_2 || key == GLFW.GLFW_KEY_KP_2) { choose(2); return true; }
        return super.keyPressed(key, scan, mods);
    }

    private void choose(int faction) {
        ModNetwork.INSTANCE.sendToServer(new FactionChoicePacket(faction));
        onClose();
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
